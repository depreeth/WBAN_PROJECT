const Parameters = [
  { id: 1, text: "Blood Sugar" },
  { id: 2, text: "Haemoglobin" },
  { id: 3, text: "Temperature" },
  { id: 4, text: "Blood Pressure" }
];
export default Parameters;
