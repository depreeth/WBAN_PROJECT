const Doctors = [
    {
        id: 1,
        img: "doc.png",
        name: "Dr. John Doe",
        specialization: "Cardiologist",
        experience: "10 years",
        contact: "9876543210"
    },
    {
        id: 2,
        img: "doc.png",
        name: "Dr. Jane Doe",
        specialization: "Neurologist",
        experience: "8 years",
        contact: "9876543211"
    },
    {
        id: 3,
        img: "doc.png",
        name: "Dr. Alex Doe",
        specialization: "Pulmonologist",
        experience: "6 years",
        contact: "9876543212"
    },
    {
        id: 4,
        img: "doc.png",
        name: "Dr. Sam Doe",
        specialization: "Nephrologist",
        experience: "5 years",
        contact: "9876543213"
    },
    {
        id: 5,
        img: "doc.png",
        name: "Dr. Emily Doe",
        specialization: "Gastroenterologist",
        experience: "7 years",
        contact: "9876543214"
    }
]

export default Doctors;