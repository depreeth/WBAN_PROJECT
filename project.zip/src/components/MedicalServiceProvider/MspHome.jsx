import React from 'react'
import Msp from './Msp.jsx'

const MspHome = () => {
  return (
    <div>
        <Msp />
    </div>
  )
}

export default MspHome;