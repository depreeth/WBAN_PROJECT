const Parameters = [
  { id: 1, text: "Blood Sugar", min: 0, max: 500 },
  { id: 2, text: "Haemoglobin", min: 0, max: 30 },
  { id: 3, text: "Temperature", min: 0, max: 100 },
  { id: 4, text: "Blood Pressure", min: 0, max: 250 },
];
export default Parameters;
